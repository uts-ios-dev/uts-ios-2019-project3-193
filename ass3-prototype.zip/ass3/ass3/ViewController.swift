//
//  ViewController.swift
//  ass3
//
//  Created by Vicky Shi on 2019/5/20.
//  Copyright © 2019 Vicky Shi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

